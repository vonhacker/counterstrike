using UnityEditor;
using UnityEngine;
using System.Collections;

public class NewBehaviourScript : Editor{

    [MenuItem("RTools/build")]
    public static void ExportResource()
    {
        Debug.Log("building" + Selection.activeObject.name);
        BuildPipeline.BuildStreamedSceneAssetBundle(new[] { "Assets/Scene/" + Selection.activeObject.name + ".unity" }, Selection.activeObject.name + ".unity3d", BuildTarget.Android);
    }
}
