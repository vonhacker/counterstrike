﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net.Sockets;
using doru.Tcp;
using System.Threading;
using System.Windows.Threading;
using System.IO;
using System.Diagnostics;

namespace miniTry
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Menu : Window
    {
        public Menu()
        {
            InitializeComponent();
            Loaded += new RoutedEventHandler(Load);
        }
        Listener _Listener;
        Sender _Sender;
        void Load(object sender, RoutedEventArgs e)
        {            
            TcpClient _TcpClient = new TcpClient("192.84.194.48",4530);
            _Listener = new Listener();
            _Sender = new Sender();
            _Sender._TcpClient = _TcpClient;
            _Listener._TcpClient = _TcpClient;
            Thread _Thread = new Thread(_Listener.Start);
            _Thread.IsBackground = true;
            _Thread.Start();            
            DispatcherTimer _DispatcherTimer = new DispatcherTimer();
            _DispatcherTimer.Start();
            _DispatcherTimer.Interval = TimeSpan.FromMilliseconds(2);
            _DispatcherTimer.Tick += new EventHandler(Update);
            _xd = new Random().Next(10);
            _yd = (10 - _xd);
            SendNick(null);
            _Sender.Send(new byte[] { (byte)PacketType.alive });
        }
        public enum PacketType : byte
        {
            gameLoaded = 48,
            points = 67,
            addPoint = 66,
            alive = 76,
            dead = 75,
            shoot = 45,
            serverid = 254,
            playerid = 89,
            possitions = 56,
            PlayerLeaved = 23,
            PlayerJoined = 24,
            map = 21,
            nick = 86,
            sendTo = 27,
        }
        private void SendNick(byte? _SendTo)
        {
            using (var _MemoryStream = new MemoryStream())
            {
                var _BinaryWriter = new BinaryWriter(_MemoryStream);
                if (_SendTo != null)
                {
                    _BinaryWriter.Write((byte)PacketType.sendTo);
                    _BinaryWriter.Write(_SendTo.Value);
                }
                _BinaryWriter.Write((byte)PacketType.nick);
                if (_Nick.Length == 0) Debugger.Break();
                _BinaryWriter.Write(_Nick);
                _Sender.Send(_MemoryStream.ToArray());
            }
        }

        double _SendSecondsElapsed;
        const int _SendInterval = 20;
        private void SendPositions()
        {
            
            _SendSecondsElapsed += Menu._TimeElapsed;
            if (_SendSecondsElapsed > _SendInterval)
            {
                _SendSecondsElapsed = _SendSecondsElapsed % _SendInterval;
                using (var _MemoryStream = new MemoryStream())
                {
                    var _BinaryWriter = new BinaryWriter(_MemoryStream);
                    _BinaryWriter.Write((byte)PacketType.possitions);
                    _BinaryWriter.Write((Int16)Canvas.GetLeft(_LocalEllipse));
                    _BinaryWriter.Write((Int16)Canvas.GetTop(_LocalEllipse));
                    _BinaryWriter.Write((Int16)1);
                    _Sender.Send(_MemoryStream.ToArray());
                }
            }
        }

        
        string _Nick = "dsaasd"+new Random().Next(99);
        public int _ID;
        DateTime _DateTime;
        public static float _TimeElapsed;
        int _x;
        int _y;
        int _xd;
        int _yd;
        void Update(object sender, EventArgs e)
        {
            if (_x > 800 || _x<0) _xd = -_xd;
            if (_y > 600 || _y < 0) _yd = -_yd;
            _x += _xd;
            _y += _yd;            
            Canvas.SetLeft(_LocalEllipse, _x);
            Canvas.SetTop(_LocalEllipse, _y);
            _TimeElapsed = (float)(DateTime.Now - _DateTime).TotalMilliseconds;
            if (_TimeElapsed > 500) _TimeElapsed = 0;
            _DateTime = DateTime.Now;
            SendPositions();

            List<byte[]> _buffers = _Listener.GetMessages();
            foreach (byte[] _data in _buffers)
            {
                using (var _MemoryStream = new MemoryStream(_data))
                {
                    var _BinaryReader = new BinaryReader(_MemoryStream);
                    int _SenderId = _BinaryReader.ReadByte();
                    var _PacketType = (PacketType)_BinaryReader.ReadByte();
                    if (_SenderId == (int)PacketType.serverid)
                    {
                        switch (_PacketType)
                        {
                            case PacketType.playerid:
                                _ID = _BinaryReader.ReadByte();
                                Debug.WriteLine("ID Received:" + _ID);
                                break;
                            case PacketType.map:
                                {
                                }
                                break;
                            default: Debugger.Break(); break;
                        }
                    }
                    else
                    {
                        if (_SenderId == _ID) Debugger.Break();
                        switch (_PacketType)
                        {
                            case PacketType.possitions:
                                {                            
                                    int _X =_BinaryReader.ReadInt16();
                                    int _Y =_BinaryReader.ReadInt16();
                                    Canvas.SetLeft(_Ellipse, _X);
                                    Canvas.SetTop(_Ellipse, _Y);
                                }
                                break;
                            case PacketType.addPoint:
                                {
                                }
                                break;
                            case PacketType.points:
                                {
                                }
                                break;
                            case PacketType.shoot:
                                {
                                }
                                break;
                            case PacketType.PlayerJoined:
                                _Sender.Send(new byte[] { (byte)PacketType.sendTo, (byte)_SenderId, (byte)PacketType.alive });
                                break;
                            case PacketType.gameLoaded:
                                Debug.WriteLine("Game Loaded Packet Received");
                                _Sender.Send(new byte[] { (byte)PacketType.sendTo, (byte)_SenderId, (byte)PacketType.alive });
                                break;
                            case PacketType.PlayerLeaved:
                                Debug.WriteLine("Player Leaved " + _SenderId);
                                break;
                            case PacketType.dead:
                                {
                                }
                                break;
                            case PacketType.alive:
                                {
                                }
                                break;
                            case PacketType.nick:
                                {
                                }
                                break;
                            
                        }
                    }

                }
            }
        }

 
    }
}
