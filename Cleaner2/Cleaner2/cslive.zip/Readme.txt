Run Server.bat
Go to http://igorlevochkin.ig.funpic.org/cs/serv.php and you will see own server in list.